﻿namespace TheContinentalHotel.Models
{
    public class Habitacion
    {
        public int Id { get; set; }
        public string Numero { get; set; }
        public string Tipo { get; set; } // Individual, Doble, Suite
        public int PrecioPorNoche { get; set; }
        public bool Activa { get; set; } // true = activa, false = inactiva
    }
}