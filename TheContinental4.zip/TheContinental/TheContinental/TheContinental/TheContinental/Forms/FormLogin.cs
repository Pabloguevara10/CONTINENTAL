﻿using System;
using System.Linq;
using System.Windows.Forms;
using TheContinentalHotel.Data;
using TheContinentalHotel.Models;

namespace TheContinentalHotel.Forms
{
    public partial class FormLogin : Form
    {
        public static Usuario UsuarioAutenticado { get; private set; }

        public static void CerrarSesion()
        {
            UsuarioAutenticado = null;
        }

        public FormLogin()
        {
            InitializeComponent();

            cmbRol.Items.Add("Administrador");
            cmbRol.Items.Add("Recepcionista");
            cmbRol.SelectedIndex = 0;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string usuario = txtUsuario.Text;
            string contraseña = txtContraseña.Text;

            if (cmbRol.SelectedItem == null)
            {
                MessageBox.Show("Por favor, seleccione un rol.", "Campo Vacío", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string rolSeleccionado = cmbRol.SelectedItem.ToString();

            if (string.IsNullOrWhiteSpace(usuario) || string.IsNullOrWhiteSpace(contraseña))
            {
                MessageBox.Show("Por favor, ingrese usuario y contraseña.", "Campos Vacíos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var usuarios = GestorDatos.CargarUsuarios();

            var usuarioValido = usuarios.FirstOrDefault(u =>
                u.NombreUsuario.Equals(usuario, StringComparison.OrdinalIgnoreCase) &&
                u.Contraseña == contraseña &&
                u.Rol == rolSeleccionado);

            if (usuarioValido != null)
            {
                UsuarioAutenticado = usuarioValido;

                // --- CAMBIO DE NAVEGACIÓN ---
                // 1. Crear el menú y pasarle una referencia de este formulario (this).
                FormMenuPrincipal menu = new FormMenuPrincipal(this);
                // 2. Mostrar el menú.
                menu.Show();
                // 3. Ocultar el formulario de login.
                this.Hide();

                // Limpiar campos para la proxima vez que se muestre el login
                txtContraseña.Clear();
                cmbRol.SelectedIndex = 0;
            }
            else
            {
                MessageBox.Show("Credenciales incorrectas para el rol seleccionado. Acceso denegado.", "Error de Acceso", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtContraseña.Clear();
                txtUsuario.Focus();
            }
        }
    }
}