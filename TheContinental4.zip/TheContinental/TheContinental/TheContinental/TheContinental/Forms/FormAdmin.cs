﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TheContinentalHotel.Data;
using TheContinentalHotel.Models;

namespace TheContinentalHotel.Forms
{
    public partial class FormAdmin : Form
    {
        private List<Habitacion> _listaGlobalHabitaciones;
        private FormMenuPrincipal _menuPrincipal;

        public FormAdmin(FormMenuPrincipal menu)
        {
            InitializeComponent();
            _menuPrincipal = menu;
            this.FormClosing += (s, e) => _menuPrincipal.Show();
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormAdmin_Load(object sender, EventArgs e)
        {
            CargarDatosHabitaciones();
            LimpiarFormularioHabitacion();
            cmbTipo.Items.Add("Individual");
            cmbTipo.Items.Add("Doble");
            cmbTipo.Items.Add("Suite");
        }

        #region Pestaña Gestión de Habitaciones
        private void CargarDatosHabitaciones()
        {
            _listaGlobalHabitaciones = GestorDatos.CargarHabitaciones();
            dgvHabitaciones.DataSource = null;
            dgvHabitaciones.DataSource = _listaGlobalHabitaciones;
            dgvHabitaciones.Columns["Id"].Width = 40;
            dgvHabitaciones.Columns["PrecioPorNoche"].HeaderText = "Precio (Monedas de Oro)";
        }

        private void dgvHabitaciones_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvHabitaciones.SelectedRows.Count > 0)
            {
                var habitacionSeleccionada = (Habitacion)dgvHabitaciones.SelectedRows[0].DataBoundItem;
                txtHabitacionId.Text = habitacionSeleccionada.Id.ToString();
                txtNumero.Text = habitacionSeleccionada.Numero;
                txtPrecio.Text = habitacionSeleccionada.PrecioPorNoche.ToString();
                cmbTipo.SelectedItem = habitacionSeleccionada.Tipo;
                chkActiva.Checked = habitacionSeleccionada.Activa;
            }
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            LimpiarFormularioHabitacion();
        }

        private void LimpiarFormularioHabitacion()
        {
            txtHabitacionId.Text = "";
            txtNumero.Clear();
            txtPrecio.Text = "1";
            txtPrecio.ReadOnly = true;
            cmbTipo.SelectedIndex = -1;
            chkActiva.Checked = true;
            dgvHabitaciones.ClearSelection();
            txtNumero.Focus();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNumero.Text) || cmbTipo.SelectedItem == null)
            {
                MessageBox.Show("Por favor, complete todos los campos correctamente.", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int precio = 1;
            bool esNuevo = string.IsNullOrEmpty(txtHabitacionId.Text);

            var habitacionExistenteConMismoNumero = _listaGlobalHabitaciones.FirstOrDefault(h => h.Numero.Equals(txtNumero.Text.Trim(), StringComparison.OrdinalIgnoreCase));
            if (habitacionExistenteConMismoNumero != null && (esNuevo || habitacionExistenteConMismoNumero.Id.ToString() != txtHabitacionId.Text))
            {
                MessageBox.Show("El número de habitación ya existe.", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (esNuevo)
            {
                var nuevaHabitacion = new Habitacion
                {
                    Id = _listaGlobalHabitaciones.Any() ? _listaGlobalHabitaciones.Max(h => h.Id) + 1 : 1,
                    Numero = txtNumero.Text.Trim(),
                    Tipo = cmbTipo.SelectedItem.ToString(),
                    PrecioPorNoche = precio,
                    Activa = chkActiva.Checked
                };
                _listaGlobalHabitaciones.Add(nuevaHabitacion);
            }
            else // Es una modificación
            {
                // --- INICIO DEL CAMBIO ---
                // Antes de guardar, verificamos si la habitación tiene reservas activas.
                int idHabitacionAEditar = int.Parse(txtHabitacionId.Text);
                var reservas = GestorDatos.CargarReservas();
                if (reservas.Any(r => r.IdHabitacion == idHabitacionAEditar && r.Estado == "Reservada"))
                {
                    MessageBox.Show("No se pueden modificar las propiedades de una habitación con reservas activas.\nPara realizar cambios, primero deben cancelarse las reservas asociadas.", "Operación Denegada", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return; // Detenemos la operación de guardado.
                }
                // --- FIN DEL CAMBIO ---

                var habitacionAEditar = _listaGlobalHabitaciones.FirstOrDefault(h => h.Id == idHabitacionAEditar);
                if (habitacionAEditar != null)
                {
                    habitacionAEditar.Numero = txtNumero.Text;
                    habitacionAEditar.Tipo = cmbTipo.SelectedItem.ToString();
                    habitacionAEditar.PrecioPorNoche = precio;
                    habitacionAEditar.Activa = chkActiva.Checked;
                }
            }

            GestorDatos.GuardarHabitaciones(_listaGlobalHabitaciones);
            CargarDatosHabitaciones();
            MessageBox.Show("Habitación guardada con éxito.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtHabitacionId.Text))
            {
                MessageBox.Show("Seleccione una habitación para eliminar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            var reservas = GestorDatos.CargarReservas();
            int idHabitacion = int.Parse(txtHabitacionId.Text);
            if (reservas.Any(r => r.IdHabitacion == idHabitacion && r.Estado == "Reservada"))
            {
                MessageBox.Show("No se puede eliminar la habitación porque tiene reservas activas.", "Operación Denegada", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            var confirmacion = MessageBox.Show("¿Está seguro de que desea eliminar esta habitación?", "Confirmar Eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirmacion == DialogResult.Yes)
            {
                _listaGlobalHabitaciones.RemoveAll(h => h.Id == idHabitacion);
                GestorDatos.GuardarHabitaciones(_listaGlobalHabitaciones);
                CargarDatosHabitaciones();
                LimpiarFormularioHabitacion();
                MessageBox.Show("Habitación eliminada.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        #endregion

        #region Pestaña Reportes
        // El código de esta región no necesita cambios.
        private void btnGenerarReporte_Click(object sender, EventArgs e)
        {
            var fechaDesde = dtpReporteDesde.Value.Date;
            var fechaHasta = dtpReporteHasta.Value.Date;

            if (fechaDesde > fechaHasta)
            {
                MessageBox.Show("La fecha 'Desde' no puede ser posterior a la fecha 'Hasta'.", "Rango de Fechas Inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            var todasLasReservas = GestorDatos.CargarReservas();
            var todosLosClientes = GestorDatos.CargarClientes();

            var reservasEnRango = todasLasReservas
                .Where(r => r.Estado != "Cancelada" && r.FechaEntrada.Date >= fechaDesde && r.FechaEntrada.Date <= fechaHasta)
                .OrderBy(r => r.FechaEntrada);

            if (!reservasEnRango.Any())
            {
                rtbReporte.Text = "No se encontraron ingresos para el período seleccionado.";
                return;
            }

            StringBuilder reporte = new StringBuilder();
            reporte.AppendLine("==========================================================");
            reporte.AppendLine($"        REPORTE DE INGRESOS - THE CONTINENTAL");
            reporte.AppendLine($"      Período: {fechaDesde:dd/MM/yyyy} al {fechaHasta:dd/MM/yyyy}");
            reporte.AppendLine("==========================================================");
            reporte.AppendLine();
            reporte.AppendLine("ID Res. | Fecha Entrada | Habitación | Cliente        | Total (Monedas de Oro)");
            reporte.AppendLine("---------------------------------------------------------------------");

            int totalIngresos = 0;
            var habitaciones = GestorDatos.CargarHabitaciones();
            foreach (var reserva in reservasEnRango)
            {
                string numeroHabitacion = habitaciones.FirstOrDefault(h => h.Id == reserva.IdHabitacion)?.Numero ?? "N/A";
                string nombreCliente = todosLosClientes.FirstOrDefault(c => c.Id == reserva.IdCliente)?.NombreCompleto ?? "Desconocido";

                reporte.AppendLine($"{reserva.Id,-8} | {reserva.FechaEntrada:dd/MM/yyyy}    | {numeroHabitacion,-10} | {nombreCliente,-15} | {reserva.Total,22}");
                totalIngresos += reserva.Total;
            }
            reporte.AppendLine("---------------------------------------------------------------------");
            reporte.AppendLine($"TOTAL DE INGRESOS EN EL PERÍODO: {totalIngresos} monedas de oro");
            reporte.AppendLine("==========================================================");
            rtbReporte.Text = reporte.ToString();
        }

        private void btnExportar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(rtbReporte.Text))
            {
                MessageBox.Show("Primero debe generar un reporte para poder exportarlo.", "Reporte Vacío", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            using (SaveFileDialog saveFileDialog = new SaveFileDialog())
            {
                saveFileDialog.Filter = "Archivo de Texto (*.txt)|*.txt";
                saveFileDialog.Title = "Guardar Reporte";
                saveFileDialog.FileName = $"Reporte_Ingresos_{DateTime.Now:yyyyMMdd}.txt";
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    File.WriteAllText(saveFileDialog.FileName, rtbReporte.Text);
                    MessageBox.Show("Reporte exportado con éxito.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        #endregion
    }
}