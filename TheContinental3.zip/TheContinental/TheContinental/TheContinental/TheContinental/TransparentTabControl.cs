﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheContinentalHotel
{
    public class TransparentTabControl : TabControl
    {
        public TransparentTabControl()
        {
            // Habilitamos el soporte para colores de fondo transparentes
            SetStyle(ControlStyles.SupportsTransparentBackColor, true);
        }

        // Esta propiedad es clave para que el control se dibuje correctamente sin parpadeos
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x02000000; // Activa el estilo WS_EX_COMPOSITED
                return cp;
            }
        }

        // Nos aseguramos de que cualquier nueva pestaña que se agregue sea transparente
        protected override void OnControlAdded(ControlEventArgs e)
        {
            base.OnControlAdded(e);
            if (e.Control is TabPage)
            {
                e.Control.BackColor = Color.Transparent;
            }
        }
    }
}
