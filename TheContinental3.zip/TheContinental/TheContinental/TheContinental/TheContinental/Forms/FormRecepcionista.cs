﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using TheContinentalHotel.Data;
using TheContinentalHotel.Models;

namespace TheContinentalHotel.Forms
{
    public partial class FormRecepcionista : Form
    {
        private List<Cliente> _listaGlobalClientes;
        private List<Habitacion> _listaGlobalHabitaciones;
        private List<Reserva> _listaGlobalReservas;
        private FormMenuPrincipal _menuPrincipal;

        public FormRecepcionista(FormMenuPrincipal menu)
        {
            InitializeComponent();
            _menuPrincipal = menu;
            this.FormClosing += (s, e) => _menuPrincipal.Show();
        }

        private void FormRecepcionista_Load(object sender, EventArgs e)
        {
            CargarDatosClientes();
            CargarDatosReservas();
            dtpFechaEntrada.MinDate = DateTime.Now.Date;
            dtpFechaSalida.MinDate = DateTime.Now.Date.AddDays(1);
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #region Pestaña Clientes

        // Método auxiliar para calcular el rango
        private string DeterminarRango(int contratos)
        {
            if (contratos >= 10) return "Leyenda";
            if (contratos >= 5) return "Veterano";
            if (contratos >= 2) return "Miembro";
            return "Novato";
        }

        private void CargarDatosClientes()
        {
            // Ya no es necesario llamar a ActualizarRankingClientes aquí
            _listaGlobalClientes = GestorDatos.CargarClientes();
            dgvClientes.DataSource = null;
            dgvClientes.DataSource = _listaGlobalClientes;

            // Configurar las columnas del DataGridView para mostrar los datos correctos
            if (dgvClientes.Columns.Count > 0)
            {
                dgvClientes.Columns["Id"].Width = 40;
                dgvClientes.Columns["NombreCompleto"].HeaderText = "Nombre Completo";
                dgvClientes.Columns["NombreCompleto"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dgvClientes.Columns["Edad"].Width = 50;
                dgvClientes.Columns["Contratos"].Width = 80;
                dgvClientes.Columns["Rango"].Width = 100;
            }
        }

        private void LimpiarFormularioCliente()
        {
            txtClienteId.Text = "";
            txtNombre.Clear();
            numEdad.Value = 21;
            numContratos.Value = 0;
            lblRango.Text = "Rango: Novato";
            dgvClientes.ClearSelection();
            txtNombre.Focus();
        }

        private void dgvClientes_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvClientes.SelectedRows.Count > 0)
            {
                var cliente = (Cliente)dgvClientes.SelectedRows[0].DataBoundItem;
                txtClienteId.Text = cliente.Id.ToString();
                txtNombre.Text = cliente.NombreCompleto;

                if (cliente.Edad >= numEdad.Minimum)
                    numEdad.Value = cliente.Edad;
                else
                    numEdad.Value = numEdad.Minimum;

                numContratos.Value = cliente.Contratos;
                lblRango.Text = $"Rango: {cliente.Rango ?? "Novato"}";
            }
        }

        private void btnNuevoCliente_Click(object sender, EventArgs e)
        {
            LimpiarFormularioCliente();
        }

        private void btnGuardarCliente_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MessageBox.Show("El Nombre es un campo obligatorio.", "Error de Validación", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            bool esNuevo = string.IsNullOrEmpty(txtClienteId.Text);
            string rangoCalculado = DeterminarRango((int)numContratos.Value);

            if (esNuevo)
            {
                var nuevoCliente = new Cliente
                {
                    Id = _listaGlobalClientes.Any() ? _listaGlobalClientes.Max(c => c.Id) + 1 : 1,
                    NombreCompleto = txtNombre.Text.Trim(),
                    Edad = (int)numEdad.Value,
                    Contratos = (int)numContratos.Value,
                    Rango = rangoCalculado // Asignamos el rango calculado
                };
                _listaGlobalClientes.Add(nuevoCliente);
            }
            else
            {
                int id = int.Parse(txtClienteId.Text);
                var clienteExistente = _listaGlobalClientes.FirstOrDefault(c => c.Id == id);
                if (clienteExistente != null)
                {
                    clienteExistente.NombreCompleto = txtNombre.Text.Trim();
                    clienteExistente.Edad = (int)numEdad.Value;
                    clienteExistente.Contratos = (int)numContratos.Value;
                    clienteExistente.Rango = rangoCalculado; // Actualizamos el rango
                }
            }

            GestorDatos.GuardarClientes(_listaGlobalClientes);
            CargarDatosClientes();
            CargarDatosReservas();
            MessageBox.Show("Cliente guardado con éxito.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnEliminarCliente_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtClienteId.Text))
            {
                MessageBox.Show("Seleccione un cliente para eliminar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            int idCliente = int.Parse(txtClienteId.Text);
            var reservasActivas = GestorDatos.CargarReservas().Any(r => r.IdCliente == idCliente && r.Estado == "Reservada");
            if (reservasActivas)
            {
                MessageBox.Show("No se puede eliminar un cliente con reservas activas.", "Operación Denegada", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            var confirmacion = MessageBox.Show("¿Está seguro de que desea eliminar este cliente?", "Confirmar Eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirmacion == DialogResult.Yes)
            {
                _listaGlobalClientes.RemoveAll(c => c.Id == idCliente);
                GestorDatos.GuardarClientes(_listaGlobalClientes);
                CargarDatosClientes();
                CargarDatosReservas();
                LimpiarFormularioCliente();
                MessageBox.Show("Cliente eliminado.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // Evento que se dispara cada vez que cambia el valor del NumericUpDown de contratos
        private void numContratos_ValueChanged(object sender, EventArgs e)
        {
            // Actualiza la etiqueta del rango en tiempo real
            lblRango.Text = $"Rango: {DeterminarRango((int)numContratos.Value)}";
        }

        #endregion

        #region Pestaña Reservas
        private void CargarDatosReservas()
        {
            _listaGlobalHabitaciones = GestorDatos.CargarHabitaciones().Where(h => h.Activa).ToList();
            _listaGlobalClientes = GestorDatos.CargarClientes();
            _listaGlobalReservas = GestorDatos.CargarReservas();

            object clienteSeleccionado = cmbClientesReserva.SelectedValue;
            object habitacionSeleccionada = cmbHabitacionesReserva.SelectedValue;

            cmbClientesReserva.DataSource = null;
            cmbClientesReserva.DataSource = _listaGlobalClientes;
            cmbClientesReserva.DisplayMember = "NombreCompleto";
            cmbClientesReserva.ValueMember = "Id";

            cmbHabitacionesReserva.DataSource = null;
            cmbHabitacionesReserva.DataSource = _listaGlobalHabitaciones;
            cmbHabitacionesReserva.DisplayMember = "Numero";
            cmbHabitacionesReserva.ValueMember = "Id";

            if (clienteSeleccionado != null) cmbClientesReserva.SelectedValue = clienteSeleccionado;
            if (habitacionSeleccionada != null) cmbHabitacionesReserva.SelectedValue = habitacionSeleccionada;

            dgvReservas.DataSource = null;
            dgvReservas.DataSource = _listaGlobalReservas.Where(r => r.Estado != "Cancelada").OrderByDescending(r => r.FechaEntrada).ToList();
            if (dgvReservas.Columns["IdCliente"] != null) dgvReservas.Columns["IdCliente"].Visible = false;
            if (dgvReservas.Columns["Total"] != null) dgvReservas.Columns["Total"].HeaderText = "Total (Monedas de Oro)";
        }

        private void btnCrearReserva_Click(object sender, EventArgs e)
        {
            if (cmbClientesReserva.SelectedValue == null || cmbHabitacionesReserva.SelectedItem == null)
            {
                MessageBox.Show("Debe seleccionar un cliente y una habitación.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var clienteSeleccionado = (Cliente)cmbClientesReserva.SelectedItem;
            var habitacionSeleccionada = (Habitacion)cmbHabitacionesReserva.SelectedItem;
            DateTime fechaEntrada = dtpFechaEntrada.Value.Date;
            DateTime fechaSalida = dtpFechaSalida.Value.Date;
            if (fechaEntrada >= fechaSalida)
            {
                MessageBox.Show("La fecha de salida debe ser posterior a la fecha de entrada.", "Error de Fechas", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            bool estaDisponible = !_listaGlobalReservas.Any(r =>
                r.IdHabitacion == habitacionSeleccionada.Id &&
                r.Estado == "Reservada" &&
                fechaEntrada < r.FechaSalida &&
                fechaSalida > r.FechaEntrada);

            if (!estaDisponible)
            {
                MessageBox.Show("La habitación no está disponible en las fechas seleccionadas.", "Conflicto de Reserva", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int noches = (fechaSalida - fechaEntrada).Days;
            int total = noches * habitacionSeleccionada.PrecioPorNoche;

            var nuevaReserva = new Reserva
            {
                Id = _listaGlobalReservas.Any() ? _listaGlobalReservas.Max(r => r.Id) + 1 : 1,
                IdCliente = clienteSeleccionado.Id,
                IdHabitacion = habitacionSeleccionada.Id,
                FechaEntrada = fechaEntrada,
                FechaSalida = fechaSalida,
                Total = total,
                Estado = "Reservada"
            };
            _listaGlobalReservas.Add(nuevaReserva);
            GestorDatos.GuardarReservas(_listaGlobalReservas);
            CargarDatosReservas();
            MessageBox.Show($"Reserva creada con éxito.\nTotal a pagar: {total} moneda(s) de oro.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnCancelarReserva_Click(object sender, EventArgs e)
        {
            if (dgvReservas.SelectedRows.Count == 0)
            {
                MessageBox.Show("Seleccione una reserva para cancelar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            var reservaSeleccionada = (Reserva)dgvReservas.SelectedRows[0].DataBoundItem;
            if (reservaSeleccionada.Estado != "Reservada")
            {
                MessageBox.Show("Solo se pueden cancelar reservas en estado 'Reservada'.", "Operación no permitida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            var confirmacion = MessageBox.Show("¿Está seguro de que desea cancelar esta reserva?", "Confirmar Cancelación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirmacion == DialogResult.Yes)
            {
                var reservaACancelar = _listaGlobalReservas.FirstOrDefault(r => r.Id == reservaSeleccionada.Id);
                if (reservaACancelar != null)
                {
                    reservaACancelar.Estado = "Cancelada";
                    GestorDatos.GuardarReservas(_listaGlobalReservas);
                    CargarDatosReservas();
                    MessageBox.Show("Reserva cancelada.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void dtp_ValueChanged(object sender, EventArgs e)
        {
            if (dtpFechaEntrada.Value.Date >= dtpFechaSalida.Value.Date)
            {
                dtpFechaSalida.Value = dtpFechaEntrada.Value.AddDays(1);
            }
            dtpFechaSalida.MinDate = dtpFechaEntrada.Value.AddDays(1);

            if (cmbHabitacionesReserva.SelectedItem != null)
            {
                var habitacion = (Habitacion)cmbHabitacionesReserva.SelectedItem;
                int noches = (dtpFechaSalida.Value.Date - dtpFechaEntrada.Value.Date).Days;
                if (noches > 0)
                {
                    int total = noches * habitacion.PrecioPorNoche;
                    string monedaTexto = (total == 1) ? "moneda de oro" : "monedas de oro";
                    lblTotal.Text = $"Total: {total} {monedaTexto} ({noches} noches)";
                }
                else
                {
                    lblTotal.Text = "Total: 0 monedas de oro";
                }
            }
        }
        #endregion

        
    }
}