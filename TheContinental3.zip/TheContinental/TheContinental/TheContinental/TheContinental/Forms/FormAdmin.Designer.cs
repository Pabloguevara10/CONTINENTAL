﻿namespace TheContinentalHotel.Forms
{
    partial class FormAdmin
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControlAdmin = new System.Windows.Forms.TabControl();
            this.tabPageHabitaciones = new System.Windows.Forms.TabPage();
            this.groupBoxDatos = new System.Windows.Forms.GroupBox();
            this.btnRegresar = new System.Windows.Forms.Button();
            this.chkActiva = new System.Windows.Forms.CheckBox();
            this.labelActiva = new System.Windows.Forms.Label();
            this.cmbTipo = new System.Windows.Forms.ComboBox();
            this.labelTipo = new System.Windows.Forms.Label();
            this.txtPrecio = new System.Windows.Forms.TextBox();
            this.labelPrecio = new System.Windows.Forms.Label();
            this.txtNumero = new System.Windows.Forms.TextBox();
            this.labelNumero = new System.Windows.Forms.Label();
            this.txtHabitacionId = new System.Windows.Forms.TextBox();
            this.labelId = new System.Windows.Forms.Label();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.btnNuevo = new System.Windows.Forms.Button();
            this.dgvHabitaciones = new System.Windows.Forms.DataGridView();
            this.tabPageReportes = new System.Windows.Forms.TabPage();
            this.btnExportar = new System.Windows.Forms.Button();
            this.rtbReporte = new System.Windows.Forms.RichTextBox();
            this.btnGenerarReporte = new System.Windows.Forms.Button();
            this.labelHasta = new System.Windows.Forms.Label();
            this.dtpReporteHasta = new System.Windows.Forms.DateTimePicker();
            this.labelDesde = new System.Windows.Forms.Label();
            this.dtpReporteDesde = new System.Windows.Forms.DateTimePicker();
            this.tabControlAdmin.SuspendLayout();
            this.tabPageHabitaciones.SuspendLayout();
            this.groupBoxDatos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHabitaciones)).BeginInit();
            this.tabPageReportes.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControlAdmin
            // 
            this.tabControlAdmin.Controls.Add(this.tabPageHabitaciones);
            this.tabControlAdmin.Controls.Add(this.tabPageReportes);
            this.tabControlAdmin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlAdmin.Location = new System.Drawing.Point(0, 0);
            this.tabControlAdmin.Name = "tabControlAdmin";
            this.tabControlAdmin.SelectedIndex = 0;
            this.tabControlAdmin.Size = new System.Drawing.Size(800, 450);
            this.tabControlAdmin.TabIndex = 0;
            // 
            // tabPageHabitaciones
            // 
            this.tabPageHabitaciones.BackgroundImage = global::TheContinental.Properties.Resources.Fondo_admin;
            this.tabPageHabitaciones.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPageHabitaciones.Controls.Add(this.groupBoxDatos);
            this.tabPageHabitaciones.Controls.Add(this.btnEliminar);
            this.tabPageHabitaciones.Controls.Add(this.btnGuardar);
            this.tabPageHabitaciones.Controls.Add(this.btnNuevo);
            this.tabPageHabitaciones.Controls.Add(this.dgvHabitaciones);
            this.tabPageHabitaciones.Location = new System.Drawing.Point(4, 22);
            this.tabPageHabitaciones.Name = "tabPageHabitaciones";
            this.tabPageHabitaciones.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageHabitaciones.Size = new System.Drawing.Size(792, 424);
            this.tabPageHabitaciones.TabIndex = 0;
            this.tabPageHabitaciones.Text = "Gestión de Habitaciones";
            // 
            // groupBoxDatos
            // 
            this.groupBoxDatos.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBoxDatos.BackColor = System.Drawing.Color.Transparent;
            this.groupBoxDatos.Controls.Add(this.btnRegresar);
            this.groupBoxDatos.Controls.Add(this.chkActiva);
            this.groupBoxDatos.Controls.Add(this.labelActiva);
            this.groupBoxDatos.Controls.Add(this.cmbTipo);
            this.groupBoxDatos.Controls.Add(this.labelTipo);
            this.groupBoxDatos.Controls.Add(this.txtPrecio);
            this.groupBoxDatos.Controls.Add(this.labelPrecio);
            this.groupBoxDatos.Controls.Add(this.txtNumero);
            this.groupBoxDatos.Controls.Add(this.labelNumero);
            this.groupBoxDatos.Controls.Add(this.txtHabitacionId);
            this.groupBoxDatos.Controls.Add(this.labelId);
            this.groupBoxDatos.ForeColor = System.Drawing.Color.White;
            this.groupBoxDatos.Location = new System.Drawing.Point(8, 6);
            this.groupBoxDatos.Name = "groupBoxDatos";
            this.groupBoxDatos.Size = new System.Drawing.Size(776, 119);
            this.groupBoxDatos.TabIndex = 0;
            this.groupBoxDatos.TabStop = false;
            this.groupBoxDatos.Text = "Datos de la Habitación";
            // 
            // btnRegresar
            // 
            this.btnRegresar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRegresar.BackColor = System.Drawing.Color.Maroon;
            this.btnRegresar.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegresar.ForeColor = System.Drawing.Color.White;
            this.btnRegresar.Location = new System.Drawing.Point(607, 19);
            this.btnRegresar.Name = "btnRegresar";
            this.btnRegresar.Size = new System.Drawing.Size(163, 37);
            this.btnRegresar.TabIndex = 10;
            this.btnRegresar.Text = "Regresar al Menú Principal";
            this.btnRegresar.UseVisualStyleBackColor = false;
            this.btnRegresar.Click += new System.EventHandler(this.btnRegresar_Click);
            // 
            // chkActiva
            // 
            this.chkActiva.AutoSize = true;
            this.chkActiva.Location = new System.Drawing.Point(416, 78);
            this.chkActiva.Name = "chkActiva";
            this.chkActiva.Size = new System.Drawing.Size(15, 14);
            this.chkActiva.TabIndex = 5;
            this.chkActiva.UseVisualStyleBackColor = true;
            // 
            // labelActiva
            // 
            this.labelActiva.AutoSize = true;
            this.labelActiva.BackColor = System.Drawing.Color.SaddleBrown;
            this.labelActiva.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelActiva.ForeColor = System.Drawing.SystemColors.Control;
            this.labelActiva.Location = new System.Drawing.Point(361, 75);
            this.labelActiva.Name = "labelActiva";
            this.labelActiva.Size = new System.Drawing.Size(50, 17);
            this.labelActiva.TabIndex = 8;
            this.labelActiva.Text = "Activa:";
            // 
            // cmbTipo
            // 
            this.cmbTipo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTipo.FormattingEnabled = true;
            this.cmbTipo.Location = new System.Drawing.Point(407, 34);
            this.cmbTipo.Name = "cmbTipo";
            this.cmbTipo.Size = new System.Drawing.Size(121, 21);
            this.cmbTipo.TabIndex = 3;
            // 
            // labelTipo
            // 
            this.labelTipo.AutoSize = true;
            this.labelTipo.BackColor = System.Drawing.Color.SaddleBrown;
            this.labelTipo.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTipo.ForeColor = System.Drawing.SystemColors.Control;
            this.labelTipo.Location = new System.Drawing.Point(361, 37);
            this.labelTipo.Name = "labelTipo";
            this.labelTipo.Size = new System.Drawing.Size(39, 17);
            this.labelTipo.TabIndex = 6;
            this.labelTipo.Text = "Tipo:";
            // 
            // txtPrecio
            // 
            this.txtPrecio.Location = new System.Drawing.Point(222, 72);
            this.txtPrecio.Name = "txtPrecio";
            this.txtPrecio.Size = new System.Drawing.Size(100, 20);
            this.txtPrecio.TabIndex = 4;
            // 
            // labelPrecio
            // 
            this.labelPrecio.AutoSize = true;
            this.labelPrecio.BackColor = System.Drawing.Color.SaddleBrown;
            this.labelPrecio.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPrecio.ForeColor = System.Drawing.SystemColors.Control;
            this.labelPrecio.Location = new System.Drawing.Point(117, 72);
            this.labelPrecio.Name = "labelPrecio";
            this.labelPrecio.Size = new System.Drawing.Size(100, 17);
            this.labelPrecio.TabIndex = 4;
            this.labelPrecio.Text = "Precio (noche):";
            // 
            // txtNumero
            // 
            this.txtNumero.Location = new System.Drawing.Point(222, 34);
            this.txtNumero.Name = "txtNumero";
            this.txtNumero.Size = new System.Drawing.Size(100, 20);
            this.txtNumero.TabIndex = 2;
            // 
            // labelNumero
            // 
            this.labelNumero.AutoSize = true;
            this.labelNumero.BackColor = System.Drawing.Color.SaddleBrown;
            this.labelNumero.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNumero.ForeColor = System.Drawing.SystemColors.Control;
            this.labelNumero.Location = new System.Drawing.Point(143, 34);
            this.labelNumero.Name = "labelNumero";
            this.labelNumero.Size = new System.Drawing.Size(59, 17);
            this.labelNumero.TabIndex = 2;
            this.labelNumero.Text = "Número:";
            // 
            // txtHabitacionId
            // 
            this.txtHabitacionId.Location = new System.Drawing.Point(38, 33);
            this.txtHabitacionId.Name = "txtHabitacionId";
            this.txtHabitacionId.ReadOnly = true;
            this.txtHabitacionId.Size = new System.Drawing.Size(64, 20);
            this.txtHabitacionId.TabIndex = 1;
            // 
            // labelId
            // 
            this.labelId.AutoSize = true;
            this.labelId.BackColor = System.Drawing.Color.SaddleBrown;
            this.labelId.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelId.ForeColor = System.Drawing.SystemColors.Control;
            this.labelId.Location = new System.Drawing.Point(6, 34);
            this.labelId.Name = "labelId";
            this.labelId.Size = new System.Drawing.Size(28, 17);
            this.labelId.TabIndex = 0;
            this.labelId.Text = "ID:";
            // 
            // btnEliminar
            // 
            this.btnEliminar.BackColor = System.Drawing.Color.SaddleBrown;
            this.btnEliminar.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminar.ForeColor = System.Drawing.Color.White;
            this.btnEliminar.Location = new System.Drawing.Point(250, 131);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(115, 39);
            this.btnEliminar.TabIndex = 3;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = false;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.BackColor = System.Drawing.Color.SaddleBrown;
            this.btnGuardar.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardar.ForeColor = System.Drawing.Color.White;
            this.btnGuardar.Location = new System.Drawing.Point(129, 131);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(115, 39);
            this.btnGuardar.TabIndex = 2;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = false;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btnNuevo
            // 
            this.btnNuevo.BackColor = System.Drawing.Color.SaddleBrown;
            this.btnNuevo.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNuevo.ForeColor = System.Drawing.Color.White;
            this.btnNuevo.Location = new System.Drawing.Point(8, 131);
            this.btnNuevo.Name = "btnNuevo";
            this.btnNuevo.Size = new System.Drawing.Size(115, 39);
            this.btnNuevo.TabIndex = 1;
            this.btnNuevo.Text = "Nuevo";
            this.btnNuevo.UseVisualStyleBackColor = false;
            this.btnNuevo.Click += new System.EventHandler(this.btnNuevo_Click);
            // 
            // dgvHabitaciones
            // 
            this.dgvHabitaciones.AllowUserToAddRows = false;
            this.dgvHabitaciones.AllowUserToDeleteRows = false;
            this.dgvHabitaciones.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvHabitaciones.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvHabitaciones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Goldenrod;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvHabitaciones.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvHabitaciones.Location = new System.Drawing.Point(170, 245);
            this.dgvHabitaciones.MultiSelect = false;
            this.dgvHabitaciones.Name = "dgvHabitaciones";
            this.dgvHabitaciones.ReadOnly = true;
            this.dgvHabitaciones.RowHeadersWidth = 51;
            this.dgvHabitaciones.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHabitaciones.Size = new System.Drawing.Size(460, 176);
            this.dgvHabitaciones.TabIndex = 4;
            this.dgvHabitaciones.SelectionChanged += new System.EventHandler(this.dgvHabitaciones_SelectionChanged);
            // 
            // tabPageReportes
            // 
            this.tabPageReportes.BackgroundImage = global::TheContinental.Properties.Resources.Fondo_admin;
            this.tabPageReportes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPageReportes.Controls.Add(this.btnExportar);
            this.tabPageReportes.Controls.Add(this.rtbReporte);
            this.tabPageReportes.Controls.Add(this.btnGenerarReporte);
            this.tabPageReportes.Controls.Add(this.labelHasta);
            this.tabPageReportes.Controls.Add(this.dtpReporteHasta);
            this.tabPageReportes.Controls.Add(this.labelDesde);
            this.tabPageReportes.Controls.Add(this.dtpReporteDesde);
            this.tabPageReportes.Location = new System.Drawing.Point(4, 22);
            this.tabPageReportes.Name = "tabPageReportes";
            this.tabPageReportes.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageReportes.Size = new System.Drawing.Size(792, 424);
            this.tabPageReportes.TabIndex = 1;
            this.tabPageReportes.Text = "Reportes";
            // 
            // btnExportar
            // 
            this.btnExportar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExportar.BackColor = System.Drawing.Color.SaddleBrown;
            this.btnExportar.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExportar.ForeColor = System.Drawing.Color.White;
            this.btnExportar.Location = new System.Drawing.Point(636, 9);
            this.btnExportar.Name = "btnExportar";
            this.btnExportar.Size = new System.Drawing.Size(148, 45);
            this.btnExportar.TabIndex = 3;
            this.btnExportar.Text = "Exportar a .txt";
            this.btnExportar.UseVisualStyleBackColor = false;
            this.btnExportar.Click += new System.EventHandler(this.btnExportar_Click);
            // 
            // rtbReporte
            // 
            this.rtbReporte.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rtbReporte.BackColor = System.Drawing.SystemColors.Menu;
            this.rtbReporte.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbReporte.Location = new System.Drawing.Point(116, 162);
            this.rtbReporte.Name = "rtbReporte";
            this.rtbReporte.ReadOnly = true;
            this.rtbReporte.Size = new System.Drawing.Size(572, 249);
            this.rtbReporte.TabIndex = 4;
            this.rtbReporte.Text = "";
            this.rtbReporte.WordWrap = false;
            // 
            // btnGenerarReporte
            // 
            this.btnGenerarReporte.BackColor = System.Drawing.Color.SaddleBrown;
            this.btnGenerarReporte.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerarReporte.ForeColor = System.Drawing.Color.White;
            this.btnGenerarReporte.Location = new System.Drawing.Point(482, 9);
            this.btnGenerarReporte.Name = "btnGenerarReporte";
            this.btnGenerarReporte.Size = new System.Drawing.Size(148, 45);
            this.btnGenerarReporte.TabIndex = 2;
            this.btnGenerarReporte.Text = "Generar Reporte Ingresos";
            this.btnGenerarReporte.UseVisualStyleBackColor = false;
            this.btnGenerarReporte.Click += new System.EventHandler(this.btnGenerarReporte_Click);
            // 
            // labelHasta
            // 
            this.labelHasta.AutoSize = true;
            this.labelHasta.BackColor = System.Drawing.Color.SaddleBrown;
            this.labelHasta.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHasta.ForeColor = System.Drawing.Color.White;
            this.labelHasta.Location = new System.Drawing.Point(233, 19);
            this.labelHasta.Name = "labelHasta";
            this.labelHasta.Size = new System.Drawing.Size(50, 18);
            this.labelHasta.TabIndex = 3;
            this.labelHasta.Text = "Hasta:";
            // 
            // dtpReporteHasta
            // 
            this.dtpReporteHasta.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpReporteHasta.Location = new System.Drawing.Point(289, 19);
            this.dtpReporteHasta.Name = "dtpReporteHasta";
            this.dtpReporteHasta.Size = new System.Drawing.Size(140, 20);
            this.dtpReporteHasta.TabIndex = 1;
            // 
            // labelDesde
            // 
            this.labelDesde.AutoSize = true;
            this.labelDesde.BackColor = System.Drawing.Color.SaddleBrown;
            this.labelDesde.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDesde.ForeColor = System.Drawing.Color.White;
            this.labelDesde.Location = new System.Drawing.Point(8, 19);
            this.labelDesde.Name = "labelDesde";
            this.labelDesde.Size = new System.Drawing.Size(50, 18);
            this.labelDesde.TabIndex = 1;
            this.labelDesde.Text = "Desde:";
            // 
            // dtpReporteDesde
            // 
            this.dtpReporteDesde.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpReporteDesde.Location = new System.Drawing.Point(71, 19);
            this.dtpReporteDesde.Name = "dtpReporteDesde";
            this.dtpReporteDesde.Size = new System.Drawing.Size(140, 20);
            this.dtpReporteDesde.TabIndex = 0;
            // 
            // FormAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControlAdmin);
            this.MinimumSize = new System.Drawing.Size(816, 487);
            this.Name = "FormAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Panel de Administrador - The Continental";
            this.Load += new System.EventHandler(this.FormAdmin_Load);
            this.tabControlAdmin.ResumeLayout(false);
            this.tabPageHabitaciones.ResumeLayout(false);
            this.groupBoxDatos.ResumeLayout(false);
            this.groupBoxDatos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHabitaciones)).EndInit();
            this.tabPageReportes.ResumeLayout(false);
            this.tabPageReportes.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlAdmin;
        private System.Windows.Forms.TabPage tabPageHabitaciones;
        private System.Windows.Forms.TabPage tabPageReportes;
        private System.Windows.Forms.DataGridView dgvHabitaciones;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnNuevo;
        private System.Windows.Forms.GroupBox groupBoxDatos;
        private System.Windows.Forms.TextBox txtPrecio;
        private System.Windows.Forms.Label labelPrecio;
        private System.Windows.Forms.TextBox txtNumero;
        private System.Windows.Forms.Label labelNumero;
        private System.Windows.Forms.TextBox txtHabitacionId;
        private System.Windows.Forms.Label labelId;
        private System.Windows.Forms.CheckBox chkActiva;
        private System.Windows.Forms.Label labelActiva;
        private System.Windows.Forms.ComboBox cmbTipo;
        private System.Windows.Forms.Label labelTipo;
        private System.Windows.Forms.DateTimePicker dtpReporteDesde;
        private System.Windows.Forms.Label labelDesde;
        private System.Windows.Forms.RichTextBox rtbReporte;
        private System.Windows.Forms.Button btnGenerarReporte;
        private System.Windows.Forms.Label labelHasta;
        private System.Windows.Forms.DateTimePicker dtpReporteHasta;
        private System.Windows.Forms.Button btnExportar;
        private System.Windows.Forms.Button btnRegresar;
    }
}