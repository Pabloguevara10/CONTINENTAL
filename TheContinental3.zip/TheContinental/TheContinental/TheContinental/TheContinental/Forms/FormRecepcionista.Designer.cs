﻿namespace TheContinentalHotel.Forms
{
    partial class FormRecepcionista
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.tabControlRecep = new System.Windows.Forms.TabControl();
            this.tabPageClientes = new System.Windows.Forms.TabPage();
            this.btnEliminarCliente = new System.Windows.Forms.Button();
            this.btnGuardarCliente = new System.Windows.Forms.Button();
            this.btnNuevoCliente = new System.Windows.Forms.Button();
            this.dgvClientes = new System.Windows.Forms.DataGridView();
            this.groupBoxCliente = new System.Windows.Forms.GroupBox();
            this.lblRango = new System.Windows.Forms.Label();
            this.numContratos = new System.Windows.Forms.NumericUpDown();
            this.labelContratos = new System.Windows.Forms.Label();
            this.numEdad = new System.Windows.Forms.NumericUpDown();
            this.labelEdad = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.labelNombre = new System.Windows.Forms.Label();
            this.txtClienteId = new System.Windows.Forms.TextBox();
            this.labelId = new System.Windows.Forms.Label();
            this.tabPageReservas = new System.Windows.Forms.TabPage();
            this.btnCancelarReserva = new System.Windows.Forms.Button();
            this.btnCrearReserva = new System.Windows.Forms.Button();
            this.dgvReservas = new System.Windows.Forms.DataGridView();
            this.groupBoxReserva = new System.Windows.Forms.GroupBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.dtpFechaSalida = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.dtpFechaEntrada = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbHabitacionesReserva = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbClientesReserva = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnRegresar = new System.Windows.Forms.Button();
            this.tabControlRecep.SuspendLayout();
            this.tabPageClientes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvClientes)).BeginInit();
            this.groupBoxCliente.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numContratos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numEdad)).BeginInit();
            this.tabPageReservas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReservas)).BeginInit();
            this.groupBoxReserva.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControlRecep
            // 
            this.tabControlRecep.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControlRecep.Controls.Add(this.tabPageClientes);
            this.tabControlRecep.Controls.Add(this.tabPageReservas);
            this.tabControlRecep.Location = new System.Drawing.Point(0, 30);
            this.tabControlRecep.Name = "tabControlRecep";
            this.tabControlRecep.SelectedIndex = 0;
            this.tabControlRecep.Size = new System.Drawing.Size(834, 431);
            this.tabControlRecep.TabIndex = 0;
            // 
            // tabPageClientes
            // 
            this.tabPageClientes.BackgroundImage = global::TheContinental.Properties.Resources._5148104151136317464;
            this.tabPageClientes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPageClientes.Controls.Add(this.btnEliminarCliente);
            this.tabPageClientes.Controls.Add(this.btnGuardarCliente);
            this.tabPageClientes.Controls.Add(this.btnNuevoCliente);
            this.tabPageClientes.Controls.Add(this.dgvClientes);
            this.tabPageClientes.Controls.Add(this.groupBoxCliente);
            this.tabPageClientes.Location = new System.Drawing.Point(4, 22);
            this.tabPageClientes.Name = "tabPageClientes";
            this.tabPageClientes.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tabPageClientes.Size = new System.Drawing.Size(826, 405);
            this.tabPageClientes.TabIndex = 0;
            this.tabPageClientes.Text = "Gestión de Clientes";
            this.tabPageClientes.UseVisualStyleBackColor = true;
            // 
            // btnEliminarCliente
            // 
            this.btnEliminarCliente.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnEliminarCliente.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminarCliente.ForeColor = System.Drawing.Color.White;
            this.btnEliminarCliente.Location = new System.Drawing.Point(240, 102);
            this.btnEliminarCliente.Name = "btnEliminarCliente";
            this.btnEliminarCliente.Size = new System.Drawing.Size(110, 39);
            this.btnEliminarCliente.TabIndex = 4;
            this.btnEliminarCliente.Text = "Eliminar Cliente";
            this.btnEliminarCliente.UseVisualStyleBackColor = false;
            this.btnEliminarCliente.Click += new System.EventHandler(this.btnEliminarCliente_Click);
            // 
            // btnGuardarCliente
            // 
            this.btnGuardarCliente.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnGuardarCliente.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardarCliente.ForeColor = System.Drawing.Color.White;
            this.btnGuardarCliente.Location = new System.Drawing.Point(124, 102);
            this.btnGuardarCliente.Name = "btnGuardarCliente";
            this.btnGuardarCliente.Size = new System.Drawing.Size(110, 39);
            this.btnGuardarCliente.TabIndex = 3;
            this.btnGuardarCliente.Text = "Guardar Cliente";
            this.btnGuardarCliente.UseVisualStyleBackColor = false;
            this.btnGuardarCliente.Click += new System.EventHandler(this.btnGuardarCliente_Click);
            // 
            // btnNuevoCliente
            // 
            this.btnNuevoCliente.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnNuevoCliente.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNuevoCliente.ForeColor = System.Drawing.Color.White;
            this.btnNuevoCliente.Location = new System.Drawing.Point(8, 102);
            this.btnNuevoCliente.Name = "btnNuevoCliente";
            this.btnNuevoCliente.Size = new System.Drawing.Size(110, 39);
            this.btnNuevoCliente.TabIndex = 2;
            this.btnNuevoCliente.Text = "Nuevo Cliente";
            this.btnNuevoCliente.UseVisualStyleBackColor = false;
            this.btnNuevoCliente.Click += new System.EventHandler(this.btnNuevoCliente_Click);
            // 
            // dgvClientes
            // 
            this.dgvClientes.AllowUserToAddRows = false;
            this.dgvClientes.AllowUserToDeleteRows = false;
            this.dgvClientes.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvClientes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvClientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvClientes.Location = new System.Drawing.Point(94, 176);
            this.dgvClientes.MultiSelect = false;
            this.dgvClientes.Name = "dgvClientes";
            this.dgvClientes.ReadOnly = true;
            this.dgvClientes.RowHeadersWidth = 51;
            this.dgvClientes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvClientes.Size = new System.Drawing.Size(656, 214);
            this.dgvClientes.TabIndex = 1;
            this.dgvClientes.SelectionChanged += new System.EventHandler(this.dgvClientes_SelectionChanged);
            // 
            // groupBoxCliente
            // 
            this.groupBoxCliente.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBoxCliente.Controls.Add(this.lblRango);
            this.groupBoxCliente.Controls.Add(this.numContratos);
            this.groupBoxCliente.Controls.Add(this.labelContratos);
            this.groupBoxCliente.Controls.Add(this.numEdad);
            this.groupBoxCliente.Controls.Add(this.labelEdad);
            this.groupBoxCliente.Controls.Add(this.txtNombre);
            this.groupBoxCliente.Controls.Add(this.labelNombre);
            this.groupBoxCliente.Controls.Add(this.txtClienteId);
            this.groupBoxCliente.Controls.Add(this.labelId);
            this.groupBoxCliente.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBoxCliente.Location = new System.Drawing.Point(8, 6);
            this.groupBoxCliente.Name = "groupBoxCliente";
            this.groupBoxCliente.Size = new System.Drawing.Size(810, 90);
            this.groupBoxCliente.TabIndex = 0;
            this.groupBoxCliente.TabStop = false;
            this.groupBoxCliente.Text = "Datos del Cliente";
            // 
            // lblRango
            // 
            this.lblRango.AutoSize = true;
            this.lblRango.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.lblRango.Font = new System.Drawing.Font("Modern No. 20", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRango.ForeColor = System.Drawing.SystemColors.Control;
            this.lblRango.Location = new System.Drawing.Point(530, 42);
            this.lblRango.Name = "lblRango";
            this.lblRango.Size = new System.Drawing.Size(71, 15);
            this.lblRango.TabIndex = 10;
            this.lblRango.Text = "Rango: N/A";
            // 
            // numContratos
            // 
            this.numContratos.Location = new System.Drawing.Point(410, 56);
            this.numContratos.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numContratos.Name = "numContratos";
            this.numContratos.Size = new System.Drawing.Size(75, 20);
            this.numContratos.TabIndex = 3;
            this.numContratos.ValueChanged += new System.EventHandler(this.numContratos_ValueChanged);
            // 
            // labelContratos
            // 
            this.labelContratos.AutoSize = true;
            this.labelContratos.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.labelContratos.Font = new System.Drawing.Font("Modern No. 20", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelContratos.ForeColor = System.Drawing.SystemColors.Control;
            this.labelContratos.Location = new System.Drawing.Point(323, 58);
            this.labelContratos.Name = "labelContratos";
            this.labelContratos.Size = new System.Drawing.Size(66, 15);
            this.labelContratos.TabIndex = 9;
            this.labelContratos.Text = "Contratos:";
            // 
            // numEdad
            // 
            this.numEdad.Location = new System.Drawing.Point(370, 23);
            this.numEdad.Minimum = new decimal(new int[] {
            21,
            0,
            0,
            0});
            this.numEdad.Name = "numEdad";
            this.numEdad.Size = new System.Drawing.Size(75, 20);
            this.numEdad.TabIndex = 2;
            this.numEdad.Value = new decimal(new int[] {
            21,
            0,
            0,
            0});
            // 
            // labelEdad
            // 
            this.labelEdad.AutoSize = true;
            this.labelEdad.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.labelEdad.Font = new System.Drawing.Font("Modern No. 20", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEdad.ForeColor = System.Drawing.SystemColors.Control;
            this.labelEdad.Location = new System.Drawing.Point(323, 23);
            this.labelEdad.Name = "labelEdad";
            this.labelEdad.Size = new System.Drawing.Size(41, 15);
            this.labelEdad.TabIndex = 6;
            this.labelEdad.Text = "Edad:";
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(124, 56);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(190, 20);
            this.txtNombre.TabIndex = 1;
            // 
            // labelNombre
            // 
            this.labelNombre.AutoSize = true;
            this.labelNombre.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.labelNombre.Font = new System.Drawing.Font("Modern No. 20", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNombre.ForeColor = System.Drawing.SystemColors.Control;
            this.labelNombre.Location = new System.Drawing.Point(6, 58);
            this.labelNombre.Name = "labelNombre";
            this.labelNombre.Size = new System.Drawing.Size(112, 15);
            this.labelNombre.TabIndex = 2;
            this.labelNombre.Text = "Nombre Completo:";
            // 
            // txtClienteId
            // 
            this.txtClienteId.Location = new System.Drawing.Point(124, 23);
            this.txtClienteId.Name = "txtClienteId";
            this.txtClienteId.ReadOnly = true;
            this.txtClienteId.Size = new System.Drawing.Size(100, 20);
            this.txtClienteId.TabIndex = 0;
            // 
            // labelId
            // 
            this.labelId.AutoSize = true;
            this.labelId.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.labelId.Font = new System.Drawing.Font("Modern No. 20", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelId.ForeColor = System.Drawing.SystemColors.Control;
            this.labelId.Location = new System.Drawing.Point(6, 23);
            this.labelId.Name = "labelId";
            this.labelId.Size = new System.Drawing.Size(27, 15);
            this.labelId.TabIndex = 0;
            this.labelId.Text = "ID:";
            // 
            // tabPageReservas
            // 
            this.tabPageReservas.BackgroundImage = global::TheContinental.Properties.Resources._5148104151136317465;
            this.tabPageReservas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPageReservas.Controls.Add(this.btnCancelarReserva);
            this.tabPageReservas.Controls.Add(this.btnCrearReserva);
            this.tabPageReservas.Controls.Add(this.dgvReservas);
            this.tabPageReservas.Controls.Add(this.groupBoxReserva);
            this.tabPageReservas.Location = new System.Drawing.Point(4, 22);
            this.tabPageReservas.Name = "tabPageReservas";
            this.tabPageReservas.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tabPageReservas.Size = new System.Drawing.Size(826, 405);
            this.tabPageReservas.TabIndex = 1;
            this.tabPageReservas.Text = "Gestión de Reservas";
            this.tabPageReservas.UseVisualStyleBackColor = true;
            // 
            // btnCancelarReserva
            // 
            this.btnCancelarReserva.BackColor = System.Drawing.Color.Black;
            this.btnCancelarReserva.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelarReserva.ForeColor = System.Drawing.Color.White;
            this.btnCancelarReserva.Location = new System.Drawing.Point(137, 144);
            this.btnCancelarReserva.Name = "btnCancelarReserva";
            this.btnCancelarReserva.Size = new System.Drawing.Size(121, 39);
            this.btnCancelarReserva.TabIndex = 3;
            this.btnCancelarReserva.Text = "Cancelar Reserva";
            this.btnCancelarReserva.UseVisualStyleBackColor = false;
            this.btnCancelarReserva.Click += new System.EventHandler(this.btnCancelarReserva_Click);
            // 
            // btnCrearReserva
            // 
            this.btnCrearReserva.BackColor = System.Drawing.Color.Black;
            this.btnCrearReserva.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCrearReserva.ForeColor = System.Drawing.Color.White;
            this.btnCrearReserva.Location = new System.Drawing.Point(8, 144);
            this.btnCrearReserva.Name = "btnCrearReserva";
            this.btnCrearReserva.Size = new System.Drawing.Size(121, 39);
            this.btnCrearReserva.TabIndex = 2;
            this.btnCrearReserva.Text = "Crear Reserva";
            this.btnCrearReserva.UseVisualStyleBackColor = false;
            this.btnCrearReserva.Click += new System.EventHandler(this.btnCrearReserva_Click);
            // 
            // dgvReservas
            // 
            this.dgvReservas.AllowUserToAddRows = false;
            this.dgvReservas.AllowUserToDeleteRows = false;
            this.dgvReservas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvReservas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvReservas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReservas.Location = new System.Drawing.Point(159, 190);
            this.dgvReservas.MultiSelect = false;
            this.dgvReservas.Name = "dgvReservas";
            this.dgvReservas.ReadOnly = true;
            this.dgvReservas.RowHeadersWidth = 51;
            this.dgvReservas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvReservas.Size = new System.Drawing.Size(512, 202);
            this.dgvReservas.TabIndex = 1;
            // 
            // groupBoxReserva
            // 
            this.groupBoxReserva.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBoxReserva.Controls.Add(this.lblTotal);
            this.groupBoxReserva.Controls.Add(this.dtpFechaSalida);
            this.groupBoxReserva.Controls.Add(this.label8);
            this.groupBoxReserva.Controls.Add(this.dtpFechaEntrada);
            this.groupBoxReserva.Controls.Add(this.label7);
            this.groupBoxReserva.Controls.Add(this.cmbHabitacionesReserva);
            this.groupBoxReserva.Controls.Add(this.label6);
            this.groupBoxReserva.Controls.Add(this.cmbClientesReserva);
            this.groupBoxReserva.Controls.Add(this.label5);
            this.groupBoxReserva.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBoxReserva.Location = new System.Drawing.Point(8, 6);
            this.groupBoxReserva.Name = "groupBoxReserva";
            this.groupBoxReserva.Size = new System.Drawing.Size(810, 132);
            this.groupBoxReserva.TabIndex = 0;
            this.groupBoxReserva.TabStop = false;
            this.groupBoxReserva.Text = "Nueva Reserva";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.ForeColor = System.Drawing.Color.Yellow;
            this.lblTotal.Location = new System.Drawing.Point(495, 96);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(186, 17);
            this.lblTotal.TabIndex = 8;
            this.lblTotal.Text = "Total: 0 monedas de oro";
            // 
            // dtpFechaSalida
            // 
            this.dtpFechaSalida.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaSalida.Location = new System.Drawing.Point(359, 96);
            this.dtpFechaSalida.Name = "dtpFechaSalida";
            this.dtpFechaSalida.Size = new System.Drawing.Size(130, 20);
            this.dtpFechaSalida.TabIndex = 7;
            this.dtpFechaSalida.ValueChanged += new System.EventHandler(this.dtp_ValueChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.Control;
            this.label8.Location = new System.Drawing.Point(257, 100);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 16);
            this.label8.TabIndex = 6;
            this.label8.Text = "Fecha Salida:";
            // 
            // dtpFechaEntrada
            // 
            this.dtpFechaEntrada.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaEntrada.Location = new System.Drawing.Point(121, 96);
            this.dtpFechaEntrada.Name = "dtpFechaEntrada";
            this.dtpFechaEntrada.Size = new System.Drawing.Size(130, 20);
            this.dtpFechaEntrada.TabIndex = 5;
            this.dtpFechaEntrada.ValueChanged += new System.EventHandler(this.dtp_ValueChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.Control;
            this.label7.Location = new System.Drawing.Point(6, 100);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(109, 16);
            this.label7.TabIndex = 4;
            this.label7.Text = "Fecha Entrada:";
            // 
            // cmbHabitacionesReserva
            // 
            this.cmbHabitacionesReserva.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbHabitacionesReserva.FormattingEnabled = true;
            this.cmbHabitacionesReserva.Location = new System.Drawing.Point(92, 60);
            this.cmbHabitacionesReserva.Name = "cmbHabitacionesReserva";
            this.cmbHabitacionesReserva.Size = new System.Drawing.Size(382, 21);
            this.cmbHabitacionesReserva.TabIndex = 3;
            this.cmbHabitacionesReserva.SelectedIndexChanged += new System.EventHandler(this.dtp_ValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Control;
            this.label6.Location = new System.Drawing.Point(6, 63);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 16);
            this.label6.TabIndex = 2;
            this.label6.Text = "Habitación:";
            // 
            // cmbClientesReserva
            // 
            this.cmbClientesReserva.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbClientesReserva.FormattingEnabled = true;
            this.cmbClientesReserva.Location = new System.Drawing.Point(92, 26);
            this.cmbClientesReserva.Name = "cmbClientesReserva";
            this.cmbClientesReserva.Size = new System.Drawing.Size(382, 21);
            this.cmbClientesReserva.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.Control;
            this.label5.Location = new System.Drawing.Point(6, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 16);
            this.label5.TabIndex = 0;
            this.label5.Text = "Cliente:";
            // 
            // btnRegresar
            // 
            this.btnRegresar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRegresar.BackColor = System.Drawing.Color.Maroon;
            this.btnRegresar.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegresar.ForeColor = System.Drawing.Color.White;
            this.btnRegresar.Location = new System.Drawing.Point(650, 4);
            this.btnRegresar.Name = "btnRegresar";
            this.btnRegresar.Size = new System.Drawing.Size(172, 42);
            this.btnRegresar.TabIndex = 11;
            this.btnRegresar.Text = "Regresar al Menú Principal";
            this.btnRegresar.UseVisualStyleBackColor = false;
            this.btnRegresar.Click += new System.EventHandler(this.btnRegresar_Click);
            // 
            // FormRecepcionista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(834, 461);
            this.Controls.Add(this.btnRegresar);
            this.Controls.Add(this.tabControlRecep);
            this.MinimumSize = new System.Drawing.Size(849, 499);
            this.Name = "FormRecepcionista";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Panel de Recepcionista - The Continental";
            this.Load += new System.EventHandler(this.FormRecepcionista_Load);
            this.tabControlRecep.ResumeLayout(false);
            this.tabPageClientes.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvClientes)).EndInit();
            this.groupBoxCliente.ResumeLayout(false);
            this.groupBoxCliente.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numContratos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numEdad)).EndInit();
            this.tabPageReservas.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvReservas)).EndInit();
            this.groupBoxReserva.ResumeLayout(false);
            this.groupBoxReserva.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlRecep;
        private System.Windows.Forms.TabPage tabPageClientes;
        private System.Windows.Forms.TabPage tabPageReservas;
        private System.Windows.Forms.DataGridView dgvClientes;
        private System.Windows.Forms.GroupBox groupBoxCliente;
        private System.Windows.Forms.Button btnEliminarCliente;
        private System.Windows.Forms.Button btnGuardarCliente;
        private System.Windows.Forms.Button btnNuevoCliente;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label labelNombre;
        private System.Windows.Forms.TextBox txtClienteId;
        private System.Windows.Forms.Label labelId;
        private System.Windows.Forms.GroupBox groupBoxReserva;
        private System.Windows.Forms.ComboBox cmbHabitacionesReserva;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbClientesReserva;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dtpFechaSalida;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dtpFechaEntrada;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Button btnCancelarReserva;
        private System.Windows.Forms.Button btnCrearReserva;
        private System.Windows.Forms.DataGridView dgvReservas;
        private System.Windows.Forms.Button btnRegresar;
        private System.Windows.Forms.Label labelEdad;
        private System.Windows.Forms.NumericUpDown numEdad;
        private System.Windows.Forms.Label lblRango;
        private System.Windows.Forms.NumericUpDown numContratos;
        private System.Windows.Forms.Label labelContratos;
    }
}