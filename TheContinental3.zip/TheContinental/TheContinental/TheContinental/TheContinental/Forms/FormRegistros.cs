﻿using System;
using System.IO;
using System.Windows.Forms;

namespace TheContinentalHotel.Forms
{
    public partial class FormRegistros : Form
    {
        private FormMenuPrincipal _menuPrincipal;

        public FormRegistros(FormMenuPrincipal menu)
        {
            InitializeComponent();
            _menuPrincipal = menu; // Guardamos la referencia
            this.FormClosing += FormRegistros_FormClosing; // Nos suscribimos al evento de cierre
        }

        private void FormRegistros_Load(object sender, EventArgs e)
        {
            CargarRegistros();
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            // Simplemente cerramos este formulario
            this.Close();
        }

        private void FormRegistros_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Al cerrar, le decimos al menú que se vuelva a mostrar
            _menuPrincipal.Show();
        }

        private void CargarRegistros()
        {
            try
            {
                rtbUsuarios.Text = CargarArchivo("usuarios.txt");
                rtbHabitaciones.Text = CargarArchivo("habitaciones.txt");
                rtbClientes.Text = CargarArchivo("clientes.txt");
                rtbReservas.Text = CargarArchivo("reservas.txt");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al leer los archivos de registro: " + ex.Message, "Error de Lectura", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string CargarArchivo(string nombreArchivo)
        {
            if (File.Exists(nombreArchivo))
            {
                return File.ReadAllText(nombreArchivo);
            }
            return $"El archivo '{nombreArchivo}' no fue encontrado o está vacío.";
        }
    }
}