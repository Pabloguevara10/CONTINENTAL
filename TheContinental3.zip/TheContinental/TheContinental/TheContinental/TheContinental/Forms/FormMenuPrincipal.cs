﻿using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace TheContinentalHotel.Forms
{
    public partial class FormMenuPrincipal : Form
    {
        private FormLogin _formLogin;
        private bool isLoggingOut = false;

        public FormMenuPrincipal(FormLogin formLogin)
        {
            InitializeComponent();
            _formLogin = formLogin;
            ConfigurarSegunRol();
            this.FormClosing += FormMenuPrincipal_FormClosing;
        }

        private void ConfigurarSegunRol()
        {
            if (FormLogin.UsuarioAutenticado != null)
            {
                lblBienvenida.Text = $"Bienvenido, {FormLogin.UsuarioAutenticado.NombreUsuario}";

                if (FormLogin.UsuarioAutenticado.Rol == "Administrador")
                {
                    btnAdmin.Visible = true;
                    btnRecepcionista.Visible = true;
                    btnRegistros.Visible = true;
                }
                else if (FormLogin.UsuarioAutenticado.Rol == "Recepcionista")
                {
                    btnAdmin.Visible = false;
                    btnRecepcionista.Visible = true;
                    btnRegistros.Visible = true;
                }
            }
        }

        private void btnAdmin_Click(object sender, EventArgs e)
        {
            FormAdmin formAdmin = new FormAdmin(this);
            formAdmin.Show();
            this.Hide();
        }

        private void btnRecepcionista_Click(object sender, EventArgs e)
        {
            FormRecepcionista formRecep = new FormRecepcionista(this);
            formRecep.Show();
            this.Hide();
        }

        private void btnRegistros_Click(object sender, EventArgs e)
        {
            string pass = Interaction.InputBox("Para continuar, por favor ingrese su contraseña:", "Verificación de Seguridad", "");

            if (pass == FormLogin.UsuarioAutenticado.Contraseña)
            {
                // CAMBIO: Lógica de navegación actualizada para este botón
                FormRegistros formReg = new FormRegistros(this);
                formReg.Show();
                this.Hide();
            }
            else if (!string.IsNullOrEmpty(pass))
            {
                MessageBox.Show("Contraseña incorrecta.", "Acceso Denegado", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void btnCerrarSesion_Click(object sender, EventArgs e)
        {
            isLoggingOut = true;
            this.Close();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void FormMenuPrincipal_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (isLoggingOut)
            {
                FormLogin.CerrarSesion();
                _formLogin.Show();
            }
            else
            {
                Application.Exit();
            }
        }
    }
}