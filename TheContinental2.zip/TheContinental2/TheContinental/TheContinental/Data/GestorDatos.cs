﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using TheContinentalHotel.Models;

namespace TheContinentalHotel.Data
{
    public static class GestorDatos
    {
        private static readonly string rutaUsuarios = "usuarios.txt";
        private static readonly string rutaHabitaciones = "habitaciones.txt";
        private static readonly string rutaClientes = "clientes.txt";
        private static readonly string rutaReservas = "reservas.txt";

        private static List<string> CargarLineasDeArchivo(string ruta)
        {
            if (!File.Exists(ruta))
            {
                File.Create(ruta).Close();
                return new List<string>();
            }
            return File.ReadAllLines(ruta).ToList();
        }

        public static List<Usuario> CargarUsuarios()
        {
            if (!File.Exists(rutaUsuarios) || new FileInfo(rutaUsuarios).Length == 0)
            {
                var defaultUsers = new List<Usuario>
                {
                    new Usuario { NombreUsuario = "Winston", Contraseña = "Continental123", Rol = "Administrador" },
                    new Usuario { NombreUsuario = "Charon", Contraseña = "concierge", Rol = "Recepcionista" }
                };
                GuardarUsuarios(defaultUsers);
                return defaultUsers;
            }

            var lista = new List<Usuario>();
            var lineas = File.ReadAllLines(rutaUsuarios);
            Usuario usuarioActual = null;

            foreach (var linea in lineas)
            {
                if (linea == "--- Usuario ---") { usuarioActual = new Usuario(); continue; }
                if (linea == "--- Fin Usuario ---") { if (usuarioActual != null) lista.Add(usuarioActual); continue; }
                if (usuarioActual == null) continue;

                var partes = linea.Split(new[] { ':' }, 2);
                if (partes.Length == 2)
                {
                    switch (partes[0])
                    {
                        case "NombreUsuario": usuarioActual.NombreUsuario = partes[1]; break;
                        case "Contraseña": usuarioActual.Contraseña = partes[1]; break;
                        case "Rol": usuarioActual.Rol = partes[1]; break;
                    }
                }
            }
            return lista;
        }

        public static void GuardarUsuarios(List<Usuario> usuarios)
        {
            var sb = new StringBuilder();
            foreach (var usuario in usuarios)
            {
                sb.AppendLine("--- Usuario ---");
                sb.AppendLine($"NombreUsuario:{usuario.NombreUsuario}");
                sb.AppendLine($"Contraseña:{usuario.Contraseña}");
                sb.AppendLine($"Rol:{usuario.Rol}");
                sb.AppendLine("--- Fin Usuario ---");
            }
            File.WriteAllText(rutaUsuarios, sb.ToString());
        }

        public static List<Habitacion> CargarHabitaciones()
        {
            if (!File.Exists(rutaHabitaciones)) return new List<Habitacion>();
            var lista = new List<Habitacion>();
            var lineas = File.ReadAllLines(rutaHabitaciones);
            Habitacion habitacionActual = null;
            foreach (var linea in lineas)
            {
                if (linea == "--- Habitacion ---") { habitacionActual = new Habitacion(); continue; }
                if (linea == "--- Fin Habitacion ---") { if (habitacionActual != null) lista.Add(habitacionActual); continue; }
                if (habitacionActual == null) continue;
                var partes = linea.Split(new[] { ':' }, 2);
                if (partes.Length == 2)
                {
                    try
                    {
                        switch (partes[0])
                        {
                            case "Id": habitacionActual.Id = int.Parse(partes[1]); break;
                            case "Numero": habitacionActual.Numero = partes[1]; break;
                            case "Tipo": habitacionActual.Tipo = partes[1]; break;
                            case "PrecioPorNoche": habitacionActual.PrecioPorNoche = int.Parse(partes[1]); break;
                            case "Activa": habitacionActual.Activa = bool.Parse(partes[1]); break;
                        }
                    }
                    catch (FormatException) { /* Omitir línea corrupta */ }
                }
            }
            return lista;
        }

        public static void GuardarHabitaciones(List<Habitacion> habitaciones)
        {
            var sb = new StringBuilder();
            foreach (var habitacion in habitaciones)
            {
                sb.AppendLine("--- Habitacion ---");
                sb.AppendLine($"Id:{habitacion.Id}");
                sb.AppendLine($"Numero:{habitacion.Numero}");
                sb.AppendLine($"Tipo:{habitacion.Tipo}");
                sb.AppendLine($"PrecioPorNoche:{habitacion.PrecioPorNoche}");
                sb.AppendLine($"Activa:{habitacion.Activa}");
                sb.AppendLine("--- Fin Habitacion ---");
            }
            File.WriteAllText(rutaHabitaciones, sb.ToString());
        }

        public static List<Cliente> CargarClientes()
        {
            if (!File.Exists(rutaClientes)) return new List<Cliente>();
            var lista = new List<Cliente>();
            var lineas = File.ReadAllLines(rutaClientes);
            Cliente clienteActual = null;
            foreach (var linea in lineas)
            {
                if (linea == "--- Cliente ---") { clienteActual = new Cliente(); continue; }
                if (linea == "--- Fin Cliente ---") { if (clienteActual != null) lista.Add(clienteActual); continue; }
                if (clienteActual == null) continue;
                var partes = linea.Split(new[] { ':' }, 2);
                if (partes.Length == 2)
                {
                    try
                    {
                        switch (partes[0])
                        {
                            case "Id": clienteActual.Id = int.Parse(partes[1]); break;
                            case "NombreCompleto": clienteActual.NombreCompleto = partes[1]; break;
                            case "Edad": clienteActual.Edad = int.Parse(partes[1]); break;
                            case "Contratos": clienteActual.Contratos = int.Parse(partes[1]); break;
                            case "Rango": clienteActual.Rango = partes[1]; break;
                        }
                    }
                    catch (FormatException) { /* Omitir */ }
                }
            }
            return lista;
        }

        public static void GuardarClientes(List<Cliente> clientes)
        {
            var sb = new StringBuilder();
            foreach (var cliente in clientes)
            {
                sb.AppendLine("--- Cliente ---");
                sb.AppendLine($"Id:{cliente.Id}");
                sb.AppendLine($"NombreCompleto:{cliente.NombreCompleto}");
                sb.AppendLine($"Edad:{cliente.Edad}");
                sb.AppendLine($"Contratos:{cliente.Contratos}");
                sb.AppendLine($"Rango:{cliente.Rango}");
                sb.AppendLine("--- Fin Cliente ---");
            }
            File.WriteAllText(rutaClientes, sb.ToString());
        }

        public static List<Reserva> CargarReservas()
        {
            if (!File.Exists(rutaReservas)) return new List<Reserva>();
            var lista = new List<Reserva>();
            var lineas = File.ReadAllLines(rutaReservas);
            Reserva reservaActual = null;
            foreach (var linea in lineas)
            {
                if (linea == "--- Reserva ---") { reservaActual = new Reserva(); continue; }
                if (linea == "--- Fin Reserva ---") { if (reservaActual != null) lista.Add(reservaActual); continue; }
                if (reservaActual == null) continue;
                var partes = linea.Split(new[] { ':' }, 2);
                if (partes.Length == 2)
                {
                    try
                    {
                        switch (partes[0])
                        {
                            case "Id": reservaActual.Id = int.Parse(partes[1]); break;
                            case "IdCliente": reservaActual.IdCliente = int.Parse(partes[1]); break;
                            case "IdHabitacion": reservaActual.IdHabitacion = int.Parse(partes[1]); break;
                            case "FechaEntrada":
                                reservaActual.FechaEntrada = DateTime.ParseExact(partes[1], "yyyy-MM-dd", CultureInfo.InvariantCulture);
                                break;
                            case "FechaSalida":
                                reservaActual.FechaSalida = DateTime.ParseExact(partes[1], "yyyy-MM-dd", CultureInfo.InvariantCulture);
                                break;
                            case "Total": reservaActual.Total = int.Parse(partes[1]); break;
                            case "Estado": reservaActual.Estado = partes[1]; break;
                        }
                    }
                    catch (FormatException) { /* Omitir línea corrupta o con formato antiguo */ }
                }
            }
            return lista;
        }

        public static void GuardarReservas(List<Reserva> reservas)
        {
            var sb = new StringBuilder();
            foreach (var reserva in reservas)
            {
                sb.AppendLine("--- Reserva ---");
                sb.AppendLine($"Id:{reserva.Id}");
                sb.AppendLine($"IdCliente:{reserva.IdCliente}");
                sb.AppendLine($"IdHabitacion:{reserva.IdHabitacion}");
                sb.AppendLine($"FechaEntrada:{reserva.FechaEntrada:yyyy-MM-dd}");
                sb.AppendLine($"FechaSalida:{reserva.FechaSalida:yyyy-MM-dd}");
                sb.AppendLine($"Total:{reserva.Total}");
                sb.AppendLine($"Estado:{reserva.Estado}");
                sb.AppendLine("--- Fin Reserva ---");
            }
            File.WriteAllText(rutaReservas, sb.ToString());
        }

        public static void ActualizarRankingClientes()
        {
            var clientes = CargarClientes();
            foreach (var cliente in clientes)
            {
                if (cliente.Contratos >= 10) cliente.Rango = "Leyenda";
                else if (cliente.Contratos >= 5) cliente.Rango = "Veterano";
                else if (cliente.Contratos >= 2) cliente.Rango = "Miembro";
                else cliente.Rango = "Novato";
            }
            GuardarClientes(clientes);
        }
    }
}