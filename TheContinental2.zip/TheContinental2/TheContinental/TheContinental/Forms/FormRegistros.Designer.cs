﻿namespace TheContinentalHotel.Forms
{
    partial class FormRegistros
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.tabControlRegistros = new System.Windows.Forms.TabControl();
            this.tabPageUsuarios = new System.Windows.Forms.TabPage();
            this.rtbUsuarios = new System.Windows.Forms.RichTextBox();
            this.tabPageHabitaciones = new System.Windows.Forms.TabPage();
            this.rtbHabitaciones = new System.Windows.Forms.RichTextBox();
            this.tabPageClientes = new System.Windows.Forms.TabPage();
            this.rtbClientes = new System.Windows.Forms.RichTextBox();
            this.tabPageReservas = new System.Windows.Forms.TabPage();
            this.rtbReservas = new System.Windows.Forms.RichTextBox();
            this.btnRegresar = new System.Windows.Forms.Button();
            this.tabControlRegistros.SuspendLayout();
            this.tabPageUsuarios.SuspendLayout();
            this.tabPageHabitaciones.SuspendLayout();
            this.tabPageClientes.SuspendLayout();
            this.tabPageReservas.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControlRegistros
            // 
            this.tabControlRegistros.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControlRegistros.Controls.Add(this.tabPageUsuarios);
            this.tabControlRegistros.Controls.Add(this.tabPageHabitaciones);
            this.tabControlRegistros.Controls.Add(this.tabPageClientes);
            this.tabControlRegistros.Controls.Add(this.tabPageReservas);
            this.tabControlRegistros.Location = new System.Drawing.Point(0, 30);
            this.tabControlRegistros.Name = "tabControlRegistros";
            this.tabControlRegistros.SelectedIndex = 0;
            this.tabControlRegistros.Size = new System.Drawing.Size(800, 420);
            this.tabControlRegistros.TabIndex = 0;
            // 
            // tabPageUsuarios
            // 
            this.tabPageUsuarios.Controls.Add(this.rtbUsuarios);
            this.tabPageUsuarios.Location = new System.Drawing.Point(4, 22);
            this.tabPageUsuarios.Name = "tabPageUsuarios";
            this.tabPageUsuarios.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageUsuarios.Size = new System.Drawing.Size(792, 394);
            this.tabPageUsuarios.TabIndex = 0;
            this.tabPageUsuarios.Text = "usuarios.txt";
            this.tabPageUsuarios.UseVisualStyleBackColor = true;
            // 
            // rtbUsuarios
            // 
            this.rtbUsuarios.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbUsuarios.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbUsuarios.Location = new System.Drawing.Point(3, 3);
            this.rtbUsuarios.Name = "rtbUsuarios";
            this.rtbUsuarios.ReadOnly = true;
            this.rtbUsuarios.Size = new System.Drawing.Size(786, 388);
            this.rtbUsuarios.TabIndex = 0;
            this.rtbUsuarios.Text = "";
            this.rtbUsuarios.WordWrap = false;
            // 
            // tabPageHabitaciones
            // 
            this.tabPageHabitaciones.Controls.Add(this.rtbHabitaciones);
            this.tabPageHabitaciones.Location = new System.Drawing.Point(4, 22);
            this.tabPageHabitaciones.Name = "tabPageHabitaciones";
            this.tabPageHabitaciones.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageHabitaciones.Size = new System.Drawing.Size(792, 394);
            this.tabPageHabitaciones.TabIndex = 1;
            this.tabPageHabitaciones.Text = "habitaciones.txt";
            this.tabPageHabitaciones.UseVisualStyleBackColor = true;
            // 
            // rtbHabitaciones
            // 
            this.rtbHabitaciones.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbHabitaciones.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.rtbHabitaciones.Location = new System.Drawing.Point(3, 3);
            this.rtbHabitaciones.Name = "rtbHabitaciones";
            this.rtbHabitaciones.ReadOnly = true;
            this.rtbHabitaciones.Size = new System.Drawing.Size(786, 388);
            this.rtbHabitaciones.TabIndex = 0;
            this.rtbHabitaciones.Text = "";
            this.rtbHabitaciones.WordWrap = false;
            // 
            // tabPageClientes
            // 
            this.tabPageClientes.Controls.Add(this.rtbClientes);
            this.tabPageClientes.Location = new System.Drawing.Point(4, 22);
            this.tabPageClientes.Name = "tabPageClientes";
            this.tabPageClientes.Size = new System.Drawing.Size(792, 394);
            this.tabPageClientes.TabIndex = 2;
            this.tabPageClientes.Text = "clientes.txt";
            this.tabPageClientes.UseVisualStyleBackColor = true;
            // 
            // rtbClientes
            // 
            this.rtbClientes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbClientes.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.rtbClientes.Location = new System.Drawing.Point(0, 0);
            this.rtbClientes.Name = "rtbClientes";
            this.rtbClientes.ReadOnly = true;
            this.rtbClientes.Size = new System.Drawing.Size(792, 394);
            this.rtbClientes.TabIndex = 0;
            this.rtbClientes.Text = "";
            this.rtbClientes.WordWrap = false;
            // 
            // tabPageReservas
            // 
            this.tabPageReservas.Controls.Add(this.rtbReservas);
            this.tabPageReservas.Location = new System.Drawing.Point(4, 22);
            this.tabPageReservas.Name = "tabPageReservas";
            this.tabPageReservas.Size = new System.Drawing.Size(792, 394);
            this.tabPageReservas.TabIndex = 3;
            this.tabPageReservas.Text = "reservas.txt";
            this.tabPageReservas.UseVisualStyleBackColor = true;
            // 
            // rtbReservas
            // 
            this.rtbReservas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbReservas.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.rtbReservas.Location = new System.Drawing.Point(0, 0);
            this.rtbReservas.Name = "rtbReservas";
            this.rtbReservas.ReadOnly = true;
            this.rtbReservas.Size = new System.Drawing.Size(792, 394);
            this.rtbReservas.TabIndex = 0;
            this.rtbReservas.Text = "";
            this.rtbReservas.WordWrap = false;
            // 
            // btnRegresar
            // 
            this.btnRegresar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRegresar.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegresar.Location = new System.Drawing.Point(616, 4);
            this.btnRegresar.Name = "btnRegresar";
            this.btnRegresar.Size = new System.Drawing.Size(172, 23);
            this.btnRegresar.TabIndex = 1;
            this.btnRegresar.Text = "Regresar al Menú Principal";
            this.btnRegresar.UseVisualStyleBackColor = true;
            this.btnRegresar.Click += new System.EventHandler(this.btnRegresar_Click);
            // 
            // FormRegistros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnRegresar);
            this.Controls.Add(this.tabControlRegistros);
            this.Name = "FormRegistros";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Visor de Registros - The Continental";
            this.Load += new System.EventHandler(this.FormRegistros_Load);
            this.tabControlRegistros.ResumeLayout(false);
            this.tabPageUsuarios.ResumeLayout(false);
            this.tabPageHabitaciones.ResumeLayout(false);
            this.tabPageClientes.ResumeLayout(false);
            this.tabPageReservas.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlRegistros;
        private System.Windows.Forms.TabPage tabPageUsuarios;
        private System.Windows.Forms.RichTextBox rtbUsuarios;
        private System.Windows.Forms.TabPage tabPageHabitaciones;
        private System.Windows.Forms.RichTextBox rtbHabitaciones;
        private System.Windows.Forms.TabPage tabPageClientes;
        private System.Windows.Forms.RichTextBox rtbClientes;
        private System.Windows.Forms.TabPage tabPageReservas;
        private System.Windows.Forms.RichTextBox rtbReservas;
        private System.Windows.Forms.Button btnRegresar;
    }
}