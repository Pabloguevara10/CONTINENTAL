﻿namespace TheContinentalHotel.Forms
{
    partial class FormAdmin
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControlAdmin = new System.Windows.Forms.TabControl();
            this.tabPageHabitaciones = new System.Windows.Forms.TabPage();
            this.groupBoxDatos = new System.Windows.Forms.GroupBox();
            this.btnRegresar = new System.Windows.Forms.Button();
            this.chkActiva = new System.Windows.Forms.CheckBox();
            this.labelActiva = new System.Windows.Forms.Label();
            this.cmbTipo = new System.Windows.Forms.ComboBox();
            this.labelTipo = new System.Windows.Forms.Label();
            this.txtPrecio = new System.Windows.Forms.TextBox();
            this.labelPrecio = new System.Windows.Forms.Label();
            this.txtNumero = new System.Windows.Forms.TextBox();
            this.labelNumero = new System.Windows.Forms.Label();
            this.txtHabitacionId = new System.Windows.Forms.TextBox();
            this.labelId = new System.Windows.Forms.Label();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.btnNuevo = new System.Windows.Forms.Button();
            this.dgvHabitaciones = new System.Windows.Forms.DataGridView();
            this.tabPageReportes = new System.Windows.Forms.TabPage();
            this.btnExportar = new System.Windows.Forms.Button();
            this.rtbReporte = new System.Windows.Forms.RichTextBox();
            this.btnGenerarReporte = new System.Windows.Forms.Button();
            this.labelHasta = new System.Windows.Forms.Label();
            this.dtpReporteHasta = new System.Windows.Forms.DateTimePicker();
            this.labelDesde = new System.Windows.Forms.Label();
            this.dtpReporteDesde = new System.Windows.Forms.DateTimePicker();
            this.tabControlAdmin.SuspendLayout();
            this.tabPageHabitaciones.SuspendLayout();
            this.groupBoxDatos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHabitaciones)).BeginInit();
            this.tabPageReportes.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControlAdmin
            // 
            this.tabControlAdmin.Controls.Add(this.tabPageHabitaciones);
            this.tabControlAdmin.Controls.Add(this.tabPageReportes);
            this.tabControlAdmin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlAdmin.Location = new System.Drawing.Point(0, 0);
            this.tabControlAdmin.Name = "tabControlAdmin";
            this.tabControlAdmin.SelectedIndex = 0;
            this.tabControlAdmin.Size = new System.Drawing.Size(800, 450);
            this.tabControlAdmin.TabIndex = 0;
            // 
            // tabPageHabitaciones
            // 
            this.tabPageHabitaciones.Controls.Add(this.groupBoxDatos);
            this.tabPageHabitaciones.Controls.Add(this.btnEliminar);
            this.tabPageHabitaciones.Controls.Add(this.btnGuardar);
            this.tabPageHabitaciones.Controls.Add(this.btnNuevo);
            this.tabPageHabitaciones.Controls.Add(this.dgvHabitaciones);
            this.tabPageHabitaciones.Location = new System.Drawing.Point(4, 22);
            this.tabPageHabitaciones.Name = "tabPageHabitaciones";
            this.tabPageHabitaciones.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageHabitaciones.Size = new System.Drawing.Size(792, 424);
            this.tabPageHabitaciones.TabIndex = 0;
            this.tabPageHabitaciones.Text = "Gestión de Habitaciones";
            this.tabPageHabitaciones.UseVisualStyleBackColor = true;
            // 
            // groupBoxDatos
            // 
            this.groupBoxDatos.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBoxDatos.Controls.Add(this.btnRegresar);
            this.groupBoxDatos.Controls.Add(this.chkActiva);
            this.groupBoxDatos.Controls.Add(this.labelActiva);
            this.groupBoxDatos.Controls.Add(this.cmbTipo);
            this.groupBoxDatos.Controls.Add(this.labelTipo);
            this.groupBoxDatos.Controls.Add(this.txtPrecio);
            this.groupBoxDatos.Controls.Add(this.labelPrecio);
            this.groupBoxDatos.Controls.Add(this.txtNumero);
            this.groupBoxDatos.Controls.Add(this.labelNumero);
            this.groupBoxDatos.Controls.Add(this.txtHabitacionId);
            this.groupBoxDatos.Controls.Add(this.labelId);
            this.groupBoxDatos.Location = new System.Drawing.Point(8, 6);
            this.groupBoxDatos.Name = "groupBoxDatos";
            this.groupBoxDatos.Size = new System.Drawing.Size(776, 119);
            this.groupBoxDatos.TabIndex = 0;
            this.groupBoxDatos.TabStop = false;
            this.groupBoxDatos.Text = "Datos de la Habitación";
            // 
            // btnRegresar
            // 
            this.btnRegresar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRegresar.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegresar.Location = new System.Drawing.Point(598, 19);
            this.btnRegresar.Name = "btnRegresar";
            this.btnRegresar.Size = new System.Drawing.Size(172, 23);
            this.btnRegresar.TabIndex = 10;
            this.btnRegresar.Text = "Regresar al Menú Principal";
            this.btnRegresar.UseVisualStyleBackColor = true;
            this.btnRegresar.Click += new System.EventHandler(this.btnRegresar_Click);
            // 
            // chkActiva
            // 
            this.chkActiva.AutoSize = true;
            this.chkActiva.Location = new System.Drawing.Point(407, 75);
            this.chkActiva.Name = "chkActiva";
            this.chkActiva.Size = new System.Drawing.Size(15, 14);
            this.chkActiva.TabIndex = 5;
            this.chkActiva.UseVisualStyleBackColor = true;
            // 
            // labelActiva
            // 
            this.labelActiva.AutoSize = true;
            this.labelActiva.Location = new System.Drawing.Point(361, 75);
            this.labelActiva.Name = "labelActiva";
            this.labelActiva.Size = new System.Drawing.Size(40, 13);
            this.labelActiva.TabIndex = 8;
            this.labelActiva.Text = "Activa:";
            // 
            // cmbTipo
            // 
            this.cmbTipo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTipo.FormattingEnabled = true;
            this.cmbTipo.Location = new System.Drawing.Point(407, 34);
            this.cmbTipo.Name = "cmbTipo";
            this.cmbTipo.Size = new System.Drawing.Size(121, 21);
            this.cmbTipo.TabIndex = 3;
            // 
            // labelTipo
            // 
            this.labelTipo.AutoSize = true;
            this.labelTipo.Location = new System.Drawing.Point(361, 37);
            this.labelTipo.Name = "labelTipo";
            this.labelTipo.Size = new System.Drawing.Size(31, 13);
            this.labelTipo.TabIndex = 6;
            this.labelTipo.Text = "Tipo:";
            // 
            // txtPrecio
            // 
            this.txtPrecio.Location = new System.Drawing.Point(222, 72);
            this.txtPrecio.Name = "txtPrecio";
            this.txtPrecio.Size = new System.Drawing.Size(100, 20);
            this.txtPrecio.TabIndex = 4;
            // 
            // labelPrecio
            // 
            this.labelPrecio.AutoSize = true;
            this.labelPrecio.Location = new System.Drawing.Point(137, 75);
            this.labelPrecio.Name = "labelPrecio";
            this.labelPrecio.Size = new System.Drawing.Size(79, 13);
            this.labelPrecio.TabIndex = 4;
            this.labelPrecio.Text = "Precio (noche):";
            // 
            // txtNumero
            // 
            this.txtNumero.Location = new System.Drawing.Point(222, 34);
            this.txtNumero.Name = "txtNumero";
            this.txtNumero.Size = new System.Drawing.Size(100, 20);
            this.txtNumero.TabIndex = 2;
            // 
            // labelNumero
            // 
            this.labelNumero.AutoSize = true;
            this.labelNumero.Location = new System.Drawing.Point(137, 37);
            this.labelNumero.Name = "labelNumero";
            this.labelNumero.Size = new System.Drawing.Size(47, 13);
            this.labelNumero.TabIndex = 2;
            this.labelNumero.Text = "Número:";
            // 
            // txtHabitacionId
            // 
            this.txtHabitacionId.Location = new System.Drawing.Point(34, 34);
            this.txtHabitacionId.Name = "txtHabitacionId";
            this.txtHabitacionId.ReadOnly = true;
            this.txtHabitacionId.Size = new System.Drawing.Size(64, 20);
            this.txtHabitacionId.TabIndex = 1;
            // 
            // labelId
            // 
            this.labelId.AutoSize = true;
            this.labelId.Location = new System.Drawing.Point(9, 37);
            this.labelId.Name = "labelId";
            this.labelId.Size = new System.Drawing.Size(21, 13);
            this.labelId.TabIndex = 0;
            this.labelId.Text = "ID:";
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(250, 131);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(115, 23);
            this.btnEliminar.TabIndex = 3;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new System.Drawing.Point(129, 131);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(115, 23);
            this.btnGuardar.TabIndex = 2;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btnNuevo
            // 
            this.btnNuevo.Location = new System.Drawing.Point(8, 131);
            this.btnNuevo.Name = "btnNuevo";
            this.btnNuevo.Size = new System.Drawing.Size(115, 23);
            this.btnNuevo.TabIndex = 1;
            this.btnNuevo.Text = "Nuevo";
            this.btnNuevo.UseVisualStyleBackColor = true;
            this.btnNuevo.Click += new System.EventHandler(this.btnNuevo_Click);
            // 
            // dgvHabitaciones
            // 
            this.dgvHabitaciones.AllowUserToAddRows = false;
            this.dgvHabitaciones.AllowUserToDeleteRows = false;
            this.dgvHabitaciones.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvHabitaciones.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvHabitaciones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Goldenrod;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvHabitaciones.DefaultCellStyle = dataGridViewCellStyle1;
            this.dgvHabitaciones.Location = new System.Drawing.Point(8, 160);
            this.dgvHabitaciones.MultiSelect = false;
            this.dgvHabitaciones.Name = "dgvHabitaciones";
            this.dgvHabitaciones.ReadOnly = true;
            this.dgvHabitaciones.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHabitaciones.Size = new System.Drawing.Size(776, 256);
            this.dgvHabitaciones.TabIndex = 4;
            this.dgvHabitaciones.SelectionChanged += new System.EventHandler(this.dgvHabitaciones_SelectionChanged);
            // 
            // tabPageReportes
            // 
            this.tabPageReportes.Controls.Add(this.btnExportar);
            this.tabPageReportes.Controls.Add(this.rtbReporte);
            this.tabPageReportes.Controls.Add(this.btnGenerarReporte);
            this.tabPageReportes.Controls.Add(this.labelHasta);
            this.tabPageReportes.Controls.Add(this.dtpReporteHasta);
            this.tabPageReportes.Controls.Add(this.labelDesde);
            this.tabPageReportes.Controls.Add(this.dtpReporteDesde);
            this.tabPageReportes.Location = new System.Drawing.Point(4, 22);
            this.tabPageReportes.Name = "tabPageReportes";
            this.tabPageReportes.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageReportes.Size = new System.Drawing.Size(792, 424);
            this.tabPageReportes.TabIndex = 1;
            this.tabPageReportes.Text = "Reportes";
            this.tabPageReportes.UseVisualStyleBackColor = true;
            // 
            // btnExportar
            // 
            this.btnExportar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExportar.Location = new System.Drawing.Point(636, 17);
            this.btnExportar.Name = "btnExportar";
            this.btnExportar.Size = new System.Drawing.Size(148, 23);
            this.btnExportar.TabIndex = 3;
            this.btnExportar.Text = "Exportar a .txt";
            this.btnExportar.UseVisualStyleBackColor = true;
            this.btnExportar.Click += new System.EventHandler(this.btnExportar_Click);
            // 
            // rtbReporte
            // 
            this.rtbReporte.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rtbReporte.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbReporte.Location = new System.Drawing.Point(8, 49);
            this.rtbReporte.Name = "rtbReporte";
            this.rtbReporte.ReadOnly = true;
            this.rtbReporte.Size = new System.Drawing.Size(776, 367);
            this.rtbReporte.TabIndex = 4;
            this.rtbReporte.Text = "";
            this.rtbReporte.WordWrap = false;
            // 
            // btnGenerarReporte
            // 
            this.btnGenerarReporte.Location = new System.Drawing.Point(482, 17);
            this.btnGenerarReporte.Name = "btnGenerarReporte";
            this.btnGenerarReporte.Size = new System.Drawing.Size(148, 23);
            this.btnGenerarReporte.TabIndex = 2;
            this.btnGenerarReporte.Text = "Generar Reporte Ingresos";
            this.btnGenerarReporte.UseVisualStyleBackColor = true;
            this.btnGenerarReporte.Click += new System.EventHandler(this.btnGenerarReporte_Click);
            // 
            // labelHasta
            // 
            this.labelHasta.AutoSize = true;
            this.labelHasta.Location = new System.Drawing.Point(245, 22);
            this.labelHasta.Name = "labelHasta";
            this.labelHasta.Size = new System.Drawing.Size(38, 13);
            this.labelHasta.TabIndex = 3;
            this.labelHasta.Text = "Hasta:";
            // 
            // dtpReporteHasta
            // 
            this.dtpReporteHasta.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpReporteHasta.Location = new System.Drawing.Point(289, 19);
            this.dtpReporteHasta.Name = "dtpReporteHasta";
            this.dtpReporteHasta.Size = new System.Drawing.Size(140, 20);
            this.dtpReporteHasta.TabIndex = 1;
            // 
            // labelDesde
            // 
            this.labelDesde.AutoSize = true;
            this.labelDesde.Location = new System.Drawing.Point(8, 22);
            this.labelDesde.Name = "labelDesde";
            this.labelDesde.Size = new System.Drawing.Size(41, 13);
            this.labelDesde.TabIndex = 1;
            this.labelDesde.Text = "Desde:";
            // 
            // dtpReporteDesde
            // 
            this.dtpReporteDesde.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpReporteDesde.Location = new System.Drawing.Point(55, 19);
            this.dtpReporteDesde.Name = "dtpReporteDesde";
            this.dtpReporteDesde.Size = new System.Drawing.Size(140, 20);
            this.dtpReporteDesde.TabIndex = 0;
            // 
            // FormAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControlAdmin);
            this.MinimumSize = new System.Drawing.Size(816, 489);
            this.Name = "FormAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Panel de Administrador - The Continental";
            this.Load += new System.EventHandler(this.FormAdmin_Load);
            this.tabControlAdmin.ResumeLayout(false);
            this.tabPageHabitaciones.ResumeLayout(false);
            this.groupBoxDatos.ResumeLayout(false);
            this.groupBoxDatos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHabitaciones)).EndInit();
            this.tabPageReportes.ResumeLayout(false);
            this.tabPageReportes.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlAdmin;
        private System.Windows.Forms.TabPage tabPageHabitaciones;
        private System.Windows.Forms.TabPage tabPageReportes;
        private System.Windows.Forms.DataGridView dgvHabitaciones;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnNuevo;
        private System.Windows.Forms.GroupBox groupBoxDatos;
        private System.Windows.Forms.TextBox txtPrecio;
        private System.Windows.Forms.Label labelPrecio;
        private System.Windows.Forms.TextBox txtNumero;
        private System.Windows.Forms.Label labelNumero;
        private System.Windows.Forms.TextBox txtHabitacionId;
        private System.Windows.Forms.Label labelId;
        private System.Windows.Forms.CheckBox chkActiva;
        private System.Windows.Forms.Label labelActiva;
        private System.Windows.Forms.ComboBox cmbTipo;
        private System.Windows.Forms.Label labelTipo;
        private System.Windows.Forms.DateTimePicker dtpReporteDesde;
        private System.Windows.Forms.Label labelDesde;
        private System.Windows.Forms.RichTextBox rtbReporte;
        private System.Windows.Forms.Button btnGenerarReporte;
        private System.Windows.Forms.Label labelHasta;
        private System.Windows.Forms.DateTimePicker dtpReporteHasta;
        private System.Windows.Forms.Button btnExportar;
        private System.Windows.Forms.Button btnRegresar;
    }
}