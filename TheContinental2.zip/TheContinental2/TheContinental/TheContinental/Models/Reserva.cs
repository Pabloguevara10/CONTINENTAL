﻿using System;

namespace TheContinentalHotel.Models
{
    public class Reserva
    {
        public int Id { get; set; }
        public int IdCliente { get; set; }
        public int IdHabitacion { get; set; }
        public DateTime FechaEntrada { get; set; }
        public DateTime FechaSalida { get; set; }
        public int Total { get; set; }
        public string Estado { get; set; }
    }
}