﻿namespace TheContinentalHotel.Models
{
    public class Cliente
    {
        public int Id { get; set; }
        public string NombreCompleto { get; set; }
        public int Edad { get; set; }
        public int Contratos { get; set; }
        public string Rango { get; set; }
    }
}