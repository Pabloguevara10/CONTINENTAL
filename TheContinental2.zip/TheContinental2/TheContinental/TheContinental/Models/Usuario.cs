﻿namespace TheContinentalHotel.Models
{
    public class Usuario
    {
        public string NombreUsuario { get; set; }
        public string Contraseña { get; set; }
        public string Rol { get; set; } // Administrador o Recepcionista
    }
}